import { db } from "./db";
import {
  smtps,
  contacts,
  campaigns,
  campaignContacts,
  trackingLogs,
  trackingRecords,
  type Smtp,
  type InsertSmtp,
  type UpdateSmtpRequest,
  type Contact,
  type InsertContact,
  type Campaign,
  type InsertCampaign,
  type UpdateCampaignRequest,
} from "@shared/schema";
import { eq, inArray, sql } from "drizzle-orm";

// ─────────────────────────────────────────────
// Interface
// ─────────────────────────────────────────────

export interface IStorage {
  // SMTP
  getSmtps(): Promise<Smtp[]>;
  getSmtp(id: number): Promise<Smtp | undefined>;
  createSmtp(smtp: InsertSmtp): Promise<Smtp>;
  updateSmtp(id: number, updates: UpdateSmtpRequest): Promise<Smtp>;
  deleteSmtp(id: number): Promise<void>;
  resetDailyQuotas(): Promise<void>;

  // Contacts
  getContacts(filters?: { country?: string; device?: string }): Promise<Contact[]>;
  getContactsByIds(ids: number[]): Promise<Contact[]>;
  getContact(id: number): Promise<Contact | undefined>;
  createContact(contact: InsertContact): Promise<Contact>;
  updateContact(id: number, updates: Partial<Contact>): Promise<Contact>;
  deleteContact(id: number): Promise<void>;

  // Campaigns
  getCampaigns(): Promise<Campaign[]>;
  getCampaign(id: number): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: number, updates: UpdateCampaignRequest): Promise<Campaign>;
  updateCampaignContactStatus(
    campaignId: number,
    contactId: number,
    status: string
  ): Promise<void>;

  // Tracking records (opaque trackingId → campaign+contact)
  saveTrackingRecord(trackingId: string, campaignId: number, contactId: number): Promise<void>;
  getTrackingRecord(
    trackingId: string
  ): Promise<{ campaignId: number; contactId: number } | null>;

  // Tracking events
  logEvent(log: {
    campaignId: number;
    contactId: number;
    eventType: string;
    ipAddress?: string;
    country?: string;
    userAgent?: string;
    device?: string;
    os?: string;
  }): Promise<void>;
  updateContactFromEvent(
    contactId: number,
    data: { country?: string; device?: string }
  ): Promise<void>;

  // Analytics
  getDashboardStats(): Promise<{
    totalSent: number;
    openRate: number;
    clickRate: number;
    failed: number;
    deviceStats: { name: string; value: number }[];
    countryStats: { name: string; value: number }[];
  }>;
}

// ─────────────────────────────────────────────
// Implementation
// ─────────────────────────────────────────────

export class DatabaseStorage implements IStorage {
  // ── SMTPs ──────────────────────────────────

  async getSmtps(): Promise<Smtp[]> {
    return db.select().from(smtps);
  }

  async getSmtp(id: number): Promise<Smtp | undefined> {
    const [row] = await db.select().from(smtps).where(eq(smtps.id, id));
    return row;
  }

  async createSmtp(smtp: InsertSmtp): Promise<Smtp> {
    const [row] = await db.insert(smtps).values(smtp).returning();
    return row;
  }

  async updateSmtp(id: number, updates: UpdateSmtpRequest): Promise<Smtp> {
    const [row] = await db.update(smtps).set(updates).where(eq(smtps.id, id)).returning();
    return row;
  }

  async deleteSmtp(id: number): Promise<void> {
    await db.delete(smtps).where(eq(smtps.id, id));
  }

  /** Reset all SMTP usedQuota counters to 0 (call daily via cron) */
  async resetDailyQuotas(): Promise<void> {
    await db.update(smtps).set({ usedQuota: 0 });
  }

  // ── Contacts ───────────────────────────────

  async getContacts(filters?: { country?: string; device?: string }): Promise<Contact[]> {
    const all = await db.select().from(contacts);
    if (!filters?.country && !filters?.device) return all;
    return all.filter((c) => {
      if (filters.country && c.country !== filters.country) return false;
      if (filters.device && c.device !== filters.device) return false;
      return true;
    });
  }

  async getContactsByIds(ids: number[]): Promise<Contact[]> {
    if (ids.length === 0) return [];
    return db.select().from(contacts).where(inArray(contacts.id, ids));
  }

  async getContact(id: number): Promise<Contact | undefined> {
    const [row] = await db.select().from(contacts).where(eq(contacts.id, id));
    return row;
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const [row] = await db.insert(contacts).values(contact).returning();
    return row;
  }

  async updateContact(id: number, updates: Partial<Contact>): Promise<Contact> {
    const [row] = await db
      .update(contacts)
      .set(updates)
      .where(eq(contacts.id, id))
      .returning();
    return row;
  }

  async deleteContact(id: number): Promise<void> {
    await db.delete(contacts).where(eq(contacts.id, id));
  }

  // ── Campaigns ──────────────────────────────

  async getCampaigns(): Promise<Campaign[]> {
    return db.select().from(campaigns);
  }

  async getCampaign(id: number): Promise<Campaign | undefined> {
    const [row] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return row;
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [row] = await db.insert(campaigns).values(campaign).returning();
    return row;
  }

  async updateCampaign(id: number, updates: UpdateCampaignRequest): Promise<Campaign> {
    const [row] = await db
      .update(campaigns)
      .set(updates)
      .where(eq(campaigns.id, id))
      .returning();
    return row;
  }

  async updateCampaignContactStatus(
    campaignId: number,
    contactId: number,
    status: string
  ): Promise<void> {
    // Upsert: update if row exists, otherwise ignore — the row is created at send time
    const existing = await db
      .select()
      .from(campaignContacts)
      .where(
        sql`${campaignContacts.campaignId} = ${campaignId} AND ${campaignContacts.contactId} = ${contactId}`
      )
      .limit(1);

    if (existing.length > 0) {
      const now = new Date();
      const patch: Record<string, unknown> = { status };
      if (status === "opened") patch.openedAt = now;
      if (status === "clicked") patch.clickedAt = now;

      await db
        .update(campaignContacts)
        .set(patch)
        .where(
          sql`${campaignContacts.campaignId} = ${campaignId} AND ${campaignContacts.contactId} = ${contactId}`
        );
    }
  }

  // ── Tracking records ────────────────────────

  async saveTrackingRecord(
    trackingId: string,
    campaignId: number,
    contactId: number
  ): Promise<void> {
    await db
      .insert(trackingRecords)
      .values({ trackingId, campaignId, contactId });
  }

  async getTrackingRecord(
    trackingId: string
  ): Promise<{ campaignId: number; contactId: number } | null> {
    const [row] = await db
      .select()
      .from(trackingRecords)
      .where(eq(trackingRecords.trackingId, trackingId))
      .limit(1);
    return row ? { campaignId: row.campaignId, contactId: row.contactId } : null;
  }

  // ── Tracking events ─────────────────────────

  async logEvent(log: {
    campaignId: number;
    contactId: number;
    eventType: string;
    ipAddress?: string;
    country?: string;
    userAgent?: string;
    device?: string;
    os?: string;
  }): Promise<void> {
    await db.insert(trackingLogs).values(log);

    // Increment aggregate counters on the campaign row
    const campaign = await this.getCampaign(log.campaignId);
    if (!campaign) return;

    if (log.eventType === "open") {
      await this.updateCampaign(log.campaignId, {
        openCount: (campaign.openCount ?? 0) + 1,
      });
    } else if (log.eventType === "click") {
      await this.updateCampaign(log.campaignId, {
        clickCount: (campaign.clickCount ?? 0) + 1,
      });
    }
  }

  async updateContactFromEvent(
    contactId: number,
    data: { country?: string; device?: string }
  ): Promise<void> {
    const updates: Partial<Contact> = {};
    if (data.country) {
      updates.country = data.country;
      updates.lastLocation = data.country;
    }
    if (data.device) {
      updates.device = data.device;
      updates.primaryDevice = data.device;
    }
    if (Object.keys(updates).length > 0) {
      await this.updateContact(contactId, updates);
    }
  }

  // ── 4. Dashboard API ────────────────────────
  // Real aggregation from PostgreSQL — no hard-coded stubs

  async getDashboardStats() {
    // ── Aggregate from campaigns table ─────────
    const [agg] = await db
      .select({
        totalSent: sql<number>`COALESCE(SUM(${campaigns.sentCount}), 0)`,
        totalOpen: sql<number>`COALESCE(SUM(${campaigns.openCount}), 0)`,
        totalClick: sql<number>`COALESCE(SUM(${campaigns.clickCount}), 0)`,
        totalFail: sql<number>`COALESCE(SUM(${campaigns.failCount}), 0)`,
      })
      .from(campaigns);

    const totalSent = Number(agg.totalSent);
    const totalOpen = Number(agg.totalOpen);
    const totalClick = Number(agg.totalClick);
    const failed = Number(agg.totalFail);

    const openRate = totalSent > 0 ? (totalOpen / totalSent) * 100 : 0;
    const clickRate = totalSent > 0 ? (totalClick / totalSent) * 100 : 0;

    // ── Opens by Device ──────────────────────────
    const deviceRows = await db
      .select({
        name: trackingLogs.device,
        value: sql<number>`COUNT(*)`,
      })
      .from(trackingLogs)
      .where(eq(trackingLogs.eventType, "open"))
      .groupBy(trackingLogs.device);

    const deviceStats = deviceRows.map((r) => ({
      name: r.name || "Unknown",
      value: Number(r.value),
    }));

    // ── Opens by Country ─────────────────────────
    const countryRows = await db
      .select({
        name: trackingLogs.country,
        value: sql<number>`COUNT(*)`,
      })
      .from(trackingLogs)
      .where(eq(trackingLogs.eventType, "open"))
      .groupBy(trackingLogs.country)
      .orderBy(sql`COUNT(*) DESC`)
      .limit(10);

    const countryStats = countryRows.map((r) => ({
      name: r.name || "Unknown",
      value: Number(r.value),
    }));

    return {
      totalSent,
      openRate: Math.round(openRate * 10) / 10,
      clickRate: Math.round(clickRate * 10) / 10,
      failed,
      deviceStats,
      countryStats,
    };
  }
}

export const storage = new DatabaseStorage();
