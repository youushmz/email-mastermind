import type { Express, Request, Response } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import nodemailer from "nodemailer";
import { parse } from "node-html-parser";
import geoip from "geoip-lite";
import useragent from "useragent";
import crypto from "crypto";

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

/** Derive the public base URL from env or fallback to localhost */
function baseUrl(): string {
  return (process.env.APP_URL || "http://localhost:5000").replace(/\/$/, "");
}

/** Generate a unique tracking token for one email send */
function generateTrackingId(): string {
  return crypto.randomBytes(16).toString("hex");
}

/**
 * Inject tracking pixel + wrap anchor hrefs.
 * Uses a single opaque trackingId so the pixel URL does NOT expose
 * campaignId or contactId directly.
 */
function injectTracking(
  html: string,
  campaignId: number,
  contactId: number,
  trackingId: string
): string {
  const root = parse(html);

  // Wrap all external links
  root.querySelectorAll("a").forEach((link) => {
    const href = link.getAttribute("href");
    if (href && !href.startsWith("#") && !href.startsWith("mailto:")) {
      const clickUrl = `${baseUrl()}/t/${trackingId}/click?url=${encodeURIComponent(href)}`;
      link.setAttribute("href", clickUrl);
    }
  });

  // Append 1×1 tracking pixel
  const pixel = `<img src="${baseUrl()}/t/${trackingId}" width="1" height="1" style="display:none;border:0;" alt="" />`;
  return root.toString() + pixel;
}

/** Extract IP, preferring the first public IP from X-Forwarded-For */
function resolveIp(req: Request): string {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) {
    const ips = (forwarded as string).split(",").map((s) => s.trim());
    const publicIp = ips.find(
      (ip) =>
        !ip.startsWith("127.") &&
        !ip.startsWith("10.") &&
        !ip.startsWith("192.168.") &&
        !ip.startsWith("::1")
    );
    if (publicIp) return publicIp;
  }
  return req.ip || req.socket.remoteAddress || "";
}

/** Parse geo + device from a request */
function parseVisitorMeta(req: Request) {
  const ip = resolveIp(req);
  const geo = geoip.lookup(ip);
  const agent = useragent.parse(req.headers["user-agent"] || "");
  const country = geo?.country || "Unknown";
  const os = agent.os.family || "Unknown";
  const deviceFamily = agent.device.family;

  let device: string;
  if (!deviceFamily || deviceFamily === "Other") {
    device = ["Android", "iOS"].includes(os) ? "Mobile" : "Desktop";
  } else {
    device = deviceFamily;
  }

  return { ip, country, os, device, userAgent: req.headers["user-agent"] || "" };
}

// ─────────────────────────────────────────────
// SMTP sender
// ─────────────────────────────────────────────

async function sendEmail(
  smtp: {
    host: string;
    port: number;
    secure: boolean;
    username: string;
    password: string;
    name: string;
  },
  to: string,
  subject: string,
  html: string
): Promise<void> {
  const transporter = nodemailer.createTransport({
    host: smtp.host,
    port: smtp.port,
    secure: smtp.secure,
    auth: { user: smtp.username, pass: smtp.password },
    connectionTimeout: 10_000,
    greetingTimeout: 10_000,
  } as any);

  await transporter.sendMail({
    from: `"${smtp.name}" <${smtp.username}>`,
    to,
    subject,
    html,
  });
}

// ─────────────────────────────────────────────
// Seeder (dev convenience)
// ─────────────────────────────────────────────

async function seedDatabase() {
  const existingSmtps = await storage.getSmtps();
  if (existingSmtps.length === 0) {
    await storage.createSmtp({
      name: "Mailgun Primary",
      host: "smtp.mailgun.org",
      port: 587,
      username: "postmaster@mail.example.com",
      password: "password123",
      secure: false,
      dailyQuota: 5000,
      isActive: true,
    });
    await storage.createSmtp({
      name: "SendGrid Fallback",
      host: "smtp.sendgrid.net",
      port: 587,
      username: "apikey",
      password: "sg_password123",
      secure: false,
      dailyQuota: 1000,
      isActive: true,
    });
  }

  const existingContacts = await storage.getContacts();
  if (existingContacts.length === 0) {
    await storage.createContact({ email: "john.doe@example.com", firstName: "John", lastName: "Doe" });
    await storage.createContact({ email: "jane.smith@example.com", firstName: "Jane", lastName: "Smith" });
    await storage.createContact({ email: "contact@company.com", firstName: "Company", lastName: "Inc" });
  }

  const existingCampaigns = await storage.getCampaigns();
  if (existingCampaigns.length === 0) {
    const smtps = await storage.getSmtps();
    await storage.createCampaign({
      name: "Welcome Series 1",
      subject: "Welcome to our platform!",
      content:
        "<h1>Welcome!</h1><p>We are glad to have you.</p><p><a href='https://example.com'>Visit us</a></p>",
      smtpIds: smtps.map((s) => s.id),
    });
  }
}

// ─────────────────────────────────────────────
// Route registration
// ─────────────────────────────────────────────

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  await seedDatabase();

  // ────────────────────────────────────────────
  // 1. REAL-TIME TRACKING ENGINE
  // GET /t/:trackingId        → open pixel
  // GET /t/:trackingId/click  → click redirect
  // ────────────────────────────────────────────

  app.get("/t/:trackingId", async (req: Request, res: Response) => {
    const { trackingId } = req.params;

    try {
      const record = await storage.getTrackingRecord(trackingId);
      if (record) {
        const meta = parseVisitorMeta(req);

        await storage.logEvent({
          campaignId: record.campaignId,
          contactId: record.contactId,
          eventType: "open",
          ipAddress: meta.ip,
          country: meta.country,
          userAgent: meta.userAgent,
          device: meta.device,
          os: meta.os,
        });

        await storage.updateContactFromEvent(record.contactId, {
          country: meta.country,
          device: meta.device,
        });

        await storage.updateCampaignContactStatus(record.campaignId, record.contactId, "opened");
      }
    } catch (err) {
      // Never block the pixel response
      console.error("[Tracking] open error:", err);
    }

    // 1×1 transparent GIF, no-cache
    const gif = Buffer.from(
      "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
      "base64"
    );
    res.writeHead(200, {
      "Content-Type": "image/gif",
      "Content-Length": gif.length,
      "Cache-Control": "no-store, no-cache, must-revalidate",
      Pragma: "no-cache",
      Expires: "0",
    });
    res.end(gif);
  });

  app.get("/t/:trackingId/click", async (req: Request, res: Response) => {
    const { trackingId } = req.params;
    const targetUrl = decodeURIComponent((req.query.url as string) || "/");

    try {
      const record = await storage.getTrackingRecord(trackingId);
      if (record) {
        const meta = parseVisitorMeta(req);

        await storage.logEvent({
          campaignId: record.campaignId,
          contactId: record.contactId,
          eventType: "click",
          ipAddress: meta.ip,
          country: meta.country,
          userAgent: meta.userAgent,
          device: meta.device,
          os: meta.os,
        });

        await storage.updateContactFromEvent(record.contactId, {
          country: meta.country,
          device: meta.device,
        });

        await storage.updateCampaignContactStatus(record.campaignId, record.contactId, "clicked");
      }
    } catch (err) {
      console.error("[Tracking] click error:", err);
    }

    res.redirect(302, targetUrl);
  });

  // ────────────────────────────────────────────
  // SMTPs
  // ────────────────────────────────────────────

  app.get(api.smtps.list.path, async (_req, res) => {
    res.json(await storage.getSmtps());
  });

  app.post(api.smtps.create.path, async (req, res) => {
    try {
      const input = api.smtps.create.input.parse(req.body);
      res.status(201).json(await storage.createSmtp(input));
    } catch (err) {
      if (err instanceof z.ZodError)
        return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put(api.smtps.update.path, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const input = api.smtps.update.input.parse(req.body);
      const smtp = await storage.updateSmtp(id, input);
      if (!smtp) return res.status(404).json({ message: "SMTP not found" });
      res.json(smtp);
    } catch (err) {
      if (err instanceof z.ZodError)
        return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete(api.smtps.delete.path, async (req, res) => {
    await storage.deleteSmtp(Number(req.params.id));
    res.status(204).end();
  });

  app.post(api.smtps.test.path, async (req, res) => {
    const smtp = await storage.getSmtp(Number(req.params.id));
    if (!smtp) return res.status(404).json({ message: "SMTP not found" });
    try {
      await sendEmail(
        smtp,
        smtp.username,
        "SMTP Test – Email Mastermind",
        "<p>Connection test successful ✅</p>"
      );
      res.json({ success: true, message: `Connected to ${smtp.host} successfully` });
    } catch (err: any) {
      res.json({ success: false, message: `Connection failed: ${err.message}` });
    }
  });

  /** Reset daily quotas — wire to a cron or call manually */
  app.post("/api/smtps/reset-quotas", async (_req, res) => {
    await storage.resetDailyQuotas();
    res.json({ message: "Daily quotas have been reset" });
  });

  // ────────────────────────────────────────────
  // Contacts
  // ────────────────────────────────────────────

  app.get(api.contacts.list.path, async (req, res) => {
    res.json(
      await storage.getContacts({
        country: req.query.country as string,
        device: req.query.device as string,
      })
    );
  });

  app.post(api.contacts.create.path, async (req, res) => {
    try {
      const input = api.contacts.create.input.parse(req.body);
      res.status(201).json(await storage.createContact(input));
    } catch (err) {
      if (err instanceof z.ZodError)
        return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete(api.contacts.delete.path, async (req, res) => {
    await storage.deleteContact(Number(req.params.id));
    res.status(204).end();
  });

  // ────────────────────────────────────────────
  // Campaigns
  // ────────────────────────────────────────────

  app.get(api.campaigns.list.path, async (_req, res) => {
    res.json(await storage.getCampaigns());
  });

  app.get(api.campaigns.get.path, async (req, res) => {
    const campaign = await storage.getCampaign(Number(req.params.id));
    if (!campaign) return res.status(404).json({ message: "Campaign not found" });
    res.json(campaign);
  });

  app.post(api.campaigns.create.path, async (req, res) => {
    try {
      const input = api.campaigns.create.input.parse(req.body);
      res.status(201).json(await storage.createCampaign(input));
    } catch (err) {
      if (err instanceof z.ZodError)
        return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "Internal server error" });
    }
  });

  /**
   * POST /api/campaigns/:id/send
   * Body (optional): { contactIds: number[] }
   *
   * If contactIds is provided, only those contacts receive the campaign.
   * Otherwise every contact in the database is targeted.
   *
   * 2. SMART SMTP ROTATION & DAILY LIMITS
   * 3. CAMPAIGN MANAGEMENT – contact selection + trackingId injection
   */
  app.post(api.campaigns.send.path, async (req, res) => {
    const id = Number(req.params.id);
    const campaign = await storage.getCampaign(id);
    if (!campaign) return res.status(404).json({ message: "Campaign not found" });
    if (campaign.status === "sending")
      return res.status(409).json({ message: "Campaign is already sending" });

    // 3a. Resolve target contacts
    const requestedIds: number[] | undefined = req.body?.contactIds;
    const contactList = requestedIds?.length
      ? await storage.getContactsByIds(requestedIds)
      : await storage.getContacts();

    if (contactList.length === 0) {
      await storage.updateCampaign(id, { status: "completed" });
      return res.json({ message: "No contacts to send to" });
    }

    const smtpIds: number[] = campaign.smtpIds || [];
    if (smtpIds.length === 0)
      return res.status(400).json({ message: "No SMTP servers assigned to this campaign" });

    await storage.updateCampaign(id, { status: "sending" });
    // Acknowledge immediately — heavy work happens in background
    res.json({ message: "Campaign started", totalContacts: contactList.length });

    // ── Background sending ────────────────────────────────────────────────
    (async () => {
      let sentCount = 0;
      let failCount = 0;
      let smtpPointer = 0; // Round-robin pointer

      const activeSmtps = (
        await Promise.all(smtpIds.map((sid) => storage.getSmtp(sid)))
      ).filter((s) => s?.isActive) as NonNullable<
        Awaited<ReturnType<typeof storage.getSmtp>>
      >[];

      if (activeSmtps.length === 0) {
        console.error(`[Campaign ${id}] No active SMTPs.`);
        await storage.updateCampaign(id, { status: "failed" });
        return;
      }

      console.log(
        `[Campaign ${id}] Sending to ${contactList.length} contacts via ${activeSmtps.length} SMTP(s)…`
      );

      for (const contact of contactList) {
        // ── 2. Smart SMTP rotation with daily-limit skip ──────────────────
        let smtp: (typeof activeSmtps)[0] | null = null;

        for (let i = 0; i < activeSmtps.length; i++) {
          const candidate = activeSmtps[smtpPointer % activeSmtps.length];
          smtpPointer++;

          const used = candidate.usedQuota ?? 0;
          const quota = candidate.dailyQuota ?? 500;

          if (used < quota) {
            smtp = candidate;
            break;
          }

          console.warn(
            `[Campaign ${id}] SMTP "${candidate.name}" at daily limit (${used}/${quota}), skipping.`
          );
        }

        // All SMTPs exhausted — pause campaign
        if (!smtp) {
          console.error(`[Campaign ${id}] All SMTPs reached daily limits. Pausing.`);
          await storage.updateCampaign(id, { status: "failed", sentCount, failCount });
          return;
        }

        // ── 3b. Per-recipient trackingId injection ────────────────────────
        const trackingId = generateTrackingId();
        const trackedHtml = injectTracking(campaign.content, campaign.id, contact.id, trackingId);

        try {
          await sendEmail(smtp, contact.email, campaign.subject, trackedHtml);

          // Persist trackingId → (campaign, contact) before confirming success
          await storage.saveTrackingRecord(trackingId, campaign.id, contact.id);

          // Re-fetch quota to avoid stale counter from parallel operations
          const freshSmtp = await storage.getSmtp(smtp.id);
          if (freshSmtp) {
            const newQuota = (freshSmtp.usedQuota ?? 0) + 1;
            await storage.updateSmtp(smtp.id, { usedQuota: newQuota });
            smtp.usedQuota = newQuota; // keep in-memory copy in sync
          }

          sentCount++;
          console.log(`[Campaign ${id}] ✓ ${contact.email} via ${smtp.name}`);
        } catch (err) {
          console.error(`[Campaign ${id}] ✗ ${contact.email}:`, err);
          failCount++;
        }
      }

      await storage.updateCampaign(id, { status: "completed", sentCount, failCount });
      console.log(`[Campaign ${id}] Finished. Sent: ${sentCount}, Failed: ${failCount}`);
    })();
  });

  // ────────────────────────────────────────────
  // 4. DASHBOARD API – aggregated from PostgreSQL
  // ────────────────────────────────────────────

  app.get(api.analytics.dashboard.path, async (_req, res) => {
    res.json(await storage.getDashboardStats());
  });

  return httpServer;
}
